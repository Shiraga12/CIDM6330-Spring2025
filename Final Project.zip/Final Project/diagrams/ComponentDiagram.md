|   MRI_Management   |
|-------------------|
|  - API (DRF)       |
|  - Database (PostgreSQL) |
|  - Notification Service  |
|  - Billing Module  |
# External Actors:
- Patient Web Portal
- Admin Interface (Radiologist, Billing Clerk)
